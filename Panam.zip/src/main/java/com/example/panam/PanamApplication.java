package com.example.panam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
public class PanamApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanamApplication.class, args);
	}

}
