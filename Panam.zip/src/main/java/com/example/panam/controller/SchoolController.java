package com.example.panam.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
public class SchoolController {
	
	@GetMapping("/school/album")
	@PreAuthorize("isAuthenticated()")
	public String album(Model model) {
	    return "/school/album";
	}
}
