package com.example.panam.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
public class NewsController {

	@GetMapping("/news/notice")
	@PreAuthorize("isAuthenticated()")
	public String notice(Model model) {
	    return "news/notice";
	}
	@GetMapping("/news/schedules")
	@PreAuthorize("isAuthenticated()")
	public String schedules(Model model) {
	    return "news/schedules";
	}
	@GetMapping("/news/enquiry")
	@PreAuthorize("isAuthenticated()")
	public String enquiry(Model model) {
	    return "news/enquiry";
	}
}
