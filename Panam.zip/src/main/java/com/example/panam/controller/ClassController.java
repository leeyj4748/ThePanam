package com.example.panam.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller

public class ClassController {
	
	
	
	@GetMapping("/class_6/6_main")
	@PreAuthorize("isAuthenticated()")
	public String main6(Model model) {
	    return "class_6/6_main";
	}


	@GetMapping("/class_6/1_class")
	public String class6_1(Model model) {
		// 모델 데이터 설정
		return "class_6/1_class";
	}

	@GetMapping("/class_6/2_class")
	public String class6_2(Model model) {
		// 모델 데이터 설정
		return "class_6/2_class";
	}

	@GetMapping("/class_6/3_class")
	public String class6_3(Model model) {
		// 모델 데이터 설정
		return "class_6/3_class";
	}

	@GetMapping("/class_6/4_class")
	public String class6_4(Model model) {
		// 모델 데이터 설정
		return "class_6/4_class";
	}
	@GetMapping("/class_5/5_main")
	public String main5(Model model) {

		return "class_5/5_main";
	}

	@GetMapping("/class_5/1_class")
	public String class5_1(Model model) {
		// 모델 데이터 설정
		return "class_5/1_class";
	}

	@GetMapping("/class_5/2_class")
	public String class5_2(Model model) {
		// 모델 데이터 설정
		return "class_5/2_class";
	}

	@GetMapping("/class_5/3_class")
	public String class5_3(Model model) {
		// 모델 데이터 설정
		return "class_5/3_class";
	}

	@GetMapping("/class_5/4_class")
	public String class5_4(Model model) {
		// 모델 데이터 설정
		return "class_5/4_class";
	}
	@GetMapping("/class_4/4_main")
	public String main4(Model model) {

		return "class_4/4_main";
	}

	@GetMapping("/class_4/1_class")
	public String class4_1(Model model) {
		// 모델 데이터 설정
		return "class_4/1_class";
	}

	@GetMapping("/class_4/2_class")
	public String class4_2(Model model) {
		// 모델 데이터 설정
		return "class_4/2_class";
	}

	@GetMapping("/class_4/3_class")
	public String class4_3(Model model) {
		// 모델 데이터 설정
		return "class_4/3_class";
	}

	@GetMapping("/class_4/4_class")
	public String class4_4(Model model) {
		// 모델 데이터 설정
		return "class_4/4_class";
	}
	@GetMapping("/class_3/3_main")
	public String main3(Model model) {

		return "class_3/3_main";
	}

	@GetMapping("/class_3/1_class")
	public String class3_1(Model model) {
		// 모델 데이터 설정
		return "class_3/1_class";
	}

	@GetMapping("/class_3/2_class")
	public String class3_2(Model model) {
		// 모델 데이터 설정
		return "class_3/2_class";
	}

	@GetMapping("/class_3/3_class")
	public String class3_3(Model model) {
		// 모델 데이터 설정
		return "class_3/3_class";
	}

	@GetMapping("/class_3/4_class")
	public String class3_4(Model model) {
		// 모델 데이터 설정
		return "class_3/4_class";
	}
	@GetMapping("/class_2/2_main")
	public String main2(Model model) {

		return "class_2/2_main";
	}

	@GetMapping("/class_2/1_class")
	public String class2_1(Model model) {
		// 모델 데이터 설정
		return "class_2/1_class";
	}

	@GetMapping("/class_2/2_class")
	public String class2_2(Model model) {
		// 모델 데이터 설정
		return "class_2/2_class";
	}

	@GetMapping("/class_2/3_class")
	public String class2_3(Model model) {
		// 모델 데이터 설정
		return "class_2/3_class";
	}

	@GetMapping("/class_2/4_class")
	public String class2_4(Model model) {
		// 모델 데이터 설정
		return "class_2/4_class";
	}
	@GetMapping("/class_1/1_main")
	public String main1(Model model) {

		return "class_1/1_main";
	}

	@GetMapping("/class_1/1_class")
	public String class1_1(Model model) {
		// 모델 데이터 설정
		return "class_1/1_class";
	}

	@GetMapping("/class_1/2_class")
	public String class1_2(Model model) {
		// 모델 데이터 설정
		return "class_1/2_class";
	}

	@GetMapping("/class_1/3_class")
	public String class1_3(Model model) {
		// 모델 데이터 설정
		return "class_1/3_class";
	}

	@GetMapping("/class_1/4_class")
	public String class1_4(Model model) {
		// 모델 데이터 설정
		return "class_1/4_class";
	}
}
