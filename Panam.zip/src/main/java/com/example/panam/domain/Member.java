package com.example.panam.domain;

import jakarta.persistence.*;
import org.springframework.security.crypto.password.PasswordEncoder;

@Entity
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String userid;

    private String pw;

    private String roles;
    
    private String name;
    
    private String phoneNumber;
    
    private String email;
    
    private String homeAddress;
    
    private String gender;


    private Member(Long id, String userid, String pw, String roleUser, String name, String phoneNumber, String email, String homeAddress, String gender) {
        this.id = id;
        this.userid = userid;
        this.pw = pw;
        this.roles = roleUser;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.homeAddress = homeAddress;
        this.gender = gender;
    }

    protected Member() {}

    public static Member createUser(String userId, String pw, PasswordEncoder passwordEncoder, String name, String phoneNumber, String email, String homeAddress, String gender) {
        return new Member(null, userId, passwordEncoder.encode(pw), "USER", name, phoneNumber, email, homeAddress, gender);
    }

    public Long getId() {
        return id;
    }

    public String getUserid() {
        return userid;
    }

    public String getPw() {
        return pw;
    }

    public String getRoles() {
        return roles;
    }
    
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public String getEmail() {
    	return email;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public String getGender() {
        return gender;
    }
}
